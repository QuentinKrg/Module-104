/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package omjdbc.base;


import static omjdbc.base.ClaGestionMail.jTable1_sous_categories;
import static omjdbc.base.ClaGestionMail.jTextField1_Nom_Sous_Categorie;
import static omjdbc.base.ClaGestionNumero.jTable1_numéro;
import static omjdbc.base.ClaGestionNumero.jTextField1_Numéro;
import javax.swing.table.DefaultTableModel;
import static omjdbc.base.ClaGestionUser.jTable1_user;
import static omjdbc.base.ClaGestionUser.jTextField1_user;


/**
 *
  * @author zaurak (OMDB) le 13.03.2018
 * MODIFICATIONS : CLOSE DB 17.04.2018
 * exemple pour nos apprentis informaticiens
 * aussi brillants que "zaurak"
 */
public class ClaSelectLigneJtable {
    
    
    private int idSousCategorieSLget;
    
    public boolean selectionnerLigne () {    

        String nomSousCategorie;

        // OMDB 13.03.2018 : Sélectionner une ligne dans le SWING CONTROL TABLE
        int no_ligne_selectionnee = jTable1_sous_categories.getSelectedRow();
        
        // OMDB 13.03.2018 : Remplir le champ avec la valeur de la cellule sélectionnée
        DefaultTableModel tm = (DefaultTableModel)jTable1_sous_categories.getModel();
        idSousCategorieSLget = (int) tm.getValueAt(no_ligne_selectionnee, 0);

        nomSousCategorie = tm.getValueAt(no_ligne_selectionnee, 1).toString();
        jTextField1_Nom_Sous_Categorie.setText(nomSousCategorie); 
        jTextField1_Nom_Sous_Categorie.requestFocus();
        return true;
    }
    
    public boolean selectionnerLigne2 () {
        
        String numeroTelephone;
        int no_ligne_selectionee2 = jTable1_numéro.getSelectedRow();
        
        DefaultTableModel tn = (DefaultTableModel)jTable1_numéro.getModel();
        idSousCategorieSLget = (int) tn.getValueAt(no_ligne_selectionee2, 0);
        
        numeroTelephone = tn.getValueAt(no_ligne_selectionee2, 1).toString();
        jTextField1_Numéro.setText(numeroTelephone); 
        jTextField1_Numéro.requestFocus();
        
        return true; 
    }
    public boolean selectionnerLigne3 () {    

        String nomSousCategorie;

        // OMDB 13.03.2018 : Sélectionner une ligne dans le SWING CONTROL TABLE
        int no_ligne_selectionnee3 = jTable1_user.getSelectedRow();
        
        // OMDB 13.03.2018 : Remplir le champ avec la valeur de la cellule sélectionnée
        DefaultTableModel tv = (DefaultTableModel)jTable1_user.getModel();
        idSousCategorieSLget = (int) tv.getValueAt(no_ligne_selectionnee3, 0);

        nomSousCategorie = tv.getValueAt(no_ligne_selectionnee3, 1).toString();
        jTextField1_user.setText(nomSousCategorie); 
        jTextField1_user.requestFocus();
        return true;
    }
 

    public int getidSousCategorieSL()
    {
        return this.idSousCategorieSLget;
    }
    
    public void setidSousCategorieSL(int idSousCat) {
      idSousCategorieSLget = idSousCat;
    }
}
